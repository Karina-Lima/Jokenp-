package game;

import java.io.IOException;

public interface Game {
    void start() throws IOException;
}
